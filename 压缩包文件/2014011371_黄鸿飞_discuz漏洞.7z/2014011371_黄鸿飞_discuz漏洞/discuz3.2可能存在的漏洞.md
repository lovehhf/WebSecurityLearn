

- [Discuz3.2后台文件包含漏洞可后台拿shell](http://localhost/wooyun/bug_detail.php?wybug_id=wooyun-2014-065559)
- [Discuz!X ≤3.4 任意文件删除漏洞 ](https://paper.seebug.org/411/)
- [Discuz x3.2前台GET型SQL注入漏洞(绕过全局WAF)](http://localhost/wooyun/bug_detail.php?wybug_id=wooyun-2014-074970)、
- [Discuz全版本存储型DOM XSS（可打管理员）附Discuz官方开发4大坑&验证脚本](http://localhost/wooyun/bug_detail.php?wybug_id=wooyun-2015-099979)
- [x] [Discuz! x2,x2.5,x3.0,x3.1,x3.2 某插件XSS直打管理员](http://localhost/wooyun/bug_detail.php?wybug_id=wooyun-2015-0120478)